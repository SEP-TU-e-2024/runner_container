#!/bin/bash
python solver.py --verbose --strategy dqn --model_path baselines/dqn/pretrained